package com.aura.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val bg = Color.rgb(247, 245, 240)
    private val ink = Color.rgb(43, 55, 52)
    private val green = Color.rgb(72, 111, 94)
    private val prefs by lazy { getSharedPreferences("aura_local", Context.MODE_PRIVATE) }
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String, subtitle: String = "") {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(22), dp(18), dp(22), dp(16))
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        listOf("Accueil", "Journal", "Émotions", "Parler").forEach { label ->
            val b = Button(this).apply {
                text = label
                textSize = 11f
                isAllCaps = false
                setTextColor(ink)
                setBackgroundColor(bg)
                setOnClickListener {
                    when (label) {
                        "Accueil" -> showHome()
                        "Journal" -> showJournal()
                        "Émotions" -> showMood()
                        else -> showTalk()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        setContentView(root)
        addText(title, 28f, true, ink, 0, 8)
        if (subtitle.isNotBlank()) addText(subtitle, 15f, false, Color.DKGRAY, 0, 18)
    }

    private fun addText(text: String, size: Float, bold: Boolean, color: Int, top: Int = 0, bottom: Int = 10) {
        val t = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(top), 0, dp(bottom))
        }
        content.addView(t)
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, dp(52))
        p.bottomMargin = dp(10)
        content.addView(b, p)
    }

    private fun field(hint: String, multiline: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.GRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
            if (multiline) {
                minLines = 5
                gravity = Gravity.TOP
            }
        }
        val p = LinearLayout.LayoutParams(-1, if (multiline) dp(170) else dp(52))
        p.bottomMargin = dp(12)
        content.addView(e, p)
        return e
    }

    private fun card(text: String) {
        val t = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(ink)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(12)
        content.addView(t, p)
    }

    private fun showHome() {
        base("AURA", "Un espace calme pour accueillir ce que tu ressens.")
        card("Prends une respiration. Tu n’as pas besoin de tout résoudre aujourd’hui.")
        button("Écrire dans mon journal") { showJournal() }
        button("Faire le point sur mes émotions") { showMood() }
        button("Parler et réfléchir") { showTalk() }
        addText("Tes notes restent enregistrées sur cet appareil. AURA ne remplace pas un professionnel de santé.", 13f, false, Color.DKGRAY, 12, 8)
    }

    private fun showJournal() {
        base("Mon journal", "Écris librement. Ton texte est conservé localement sur ce téléphone.")
        val entry = field("Qu’aimerais-tu déposer ici ?", true)
        entry.setText(prefs.getString("journal", ""))
        button("Enregistrer mon texte") {
            prefs.edit().putString("journal", entry.text.toString()).apply()
            Toast.makeText(this, "Enregistré sur cet appareil.", Toast.LENGTH_SHORT).show()
        }
        button("Effacer mon journal") {
            entry.setText("")
            prefs.edit().remove("journal").apply()
            Toast.makeText(this, "Journal effacé.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMood() {
        base("Mes émotions", "Choisis ce qui se rapproche le plus de ton état actuel.")
        val choices = listOf("😊 Apaisé(e)", "🙂 Bien", "😐 Neutre", "😟 Inquiet(ète)", "😢 Triste", "😣 Débordé(e)")
        val saved = prefs.getString("mood", "") ?: ""
        choices.forEach { choice ->
            button(choice) {
                prefs.edit().putString("mood", choice).apply()
                Toast.makeText(this, "Émotion enregistrée.", Toast.LENGTH_SHORT).show()
                showMood()
            }
        }
        if (saved.isNotBlank()) card("Dernière émotion notée : $saved")
        addText("Les émotions changent. Une émotion difficile ne définit pas qui tu es.", 14f, false, Color.DKGRAY, 8, 8)
    }

    private fun showTalk() {
        base("Un moment pour parler", "AURA propose ici des pistes de réflexion hors ligne. Ce n’est pas encore un assistant IA connecté.")
        val input = field("Qu’est-ce qui te préoccupe ?", true)
        button("Trouver une piste de réflexion") {
            val s = input.text.toString().trim()
            val reply = when {
                s.isBlank() -> "Commence par écrire quelques mots sur ce que tu ressens."
                s.contains("stress", true) || s.contains("ango", true) || s.contains("peur", true) ->
                    "Essaie de nommer une seule chose qui te préoccupe, puis une petite action sûre et réalisable maintenant. Si tu le peux, parle aussi à une personne de confiance."
                s.contains("triste", true) || s.contains("seul", true) ->
                    "Tu mérites d’être écouté(e). Qu’aimerais-tu qu’une personne de confiance comprenne de ce que tu vis ?"
                else ->
                    "Prends un instant : qu’est-ce qui compte le plus pour toi dans cette situation, et quelle petite étape bienveillante pourrais-tu choisir ?"
            }
            card(reply)
            prefs.edit().putString("last_reflection", s).apply()
        }
        card("Si tu es en danger immédiat ou si tu crains de te faire du mal, contacte les services d’urgence de ton pays ou une personne de confiance qui peut rester avec toi.")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
